MINIMUM GODOT VERSION: 4.2

PLEASE ACTIVATE THE PLUGIN UNDER   Project -> Project Settings... -> Plugins -> DiscordRPC -> Status
IGNORE THE RED ERRORS ON THE FIRST 2 RESTARTS
READ THE TUTORIAL LINKED IN THE WINDOW THAT WILL OPEN ON PLUGIN ENABLE

If nothing works, enable the plugin and delete /addons/discord-rpc-gd/bin/.gdignore
